const tree = {
  "/home/dev": [
    { name: "Desktop", type: "dir", size: "-", modified: "10:42" },
    { name: "Documents", type: "dir", size: "-", modified: "09:18" },
    { name: "Downloads", type: "dir", size: "-", modified: "08:54" },
    { name: "deploy.log", type: "file", size: "142 KB", modified: "Yesterday" },
    { name: "backup.tar.gz", type: "file", size: "84 MB", modified: "Fri" },
  ],
  "/home/dev/Desktop": [
    { name: "server-notes.md", type: "file", size: "18 KB", modified: "May 22" },
    { name: "screenshots", type: "dir", size: "-", modified: "May 21" },
  ],
  "/home/dev/Documents": [
    { name: "keys", type: "dir", size: "-", modified: "May 19" },
    { name: "release-plan.pdf", type: "file", size: "2.4 MB", modified: "May 20" },
    { name: "database-dump.sql", type: "file", size: "31 MB", modified: "May 18" },
  ],
  "/home/dev/Downloads": [
    { name: "nginx-access.log", type: "file", size: "6.8 MB", modified: "Today" },
    { name: "app-linux-x64.zip", type: "file", size: "118 MB", modified: "Today" },
  ],
};

let currentPath = "/home/dev";
let selected = new Set();
const logLines = [];

const pathTitle = document.querySelector("#pathTitle");
const breadcrumbs = document.querySelector("#breadcrumbs");
const fileRows = document.querySelector("#fileRows");
const itemCount = document.querySelector("#itemCount");
const terminalLog = document.querySelector("#terminalLog");
const hostPath = document.querySelector("#hostPath");
const transferList = document.querySelector("#transferList");
const windows = document.querySelectorAll(".window");
const launchers = document.querySelectorAll(".launcher-item");
const taskApps = document.querySelectorAll(".task-app");
const activeApp = document.querySelector(".active-app");

function command(line, output = "") {
  logLines.push(`$ ssh dev@192.168.1.42 '${line}'`);
  if (output) logLines.push(output);
  terminalLog.textContent = logLines.slice(-28).join("\n");
  terminalLog.scrollTop = terminalLog.scrollHeight;
}

function linuxLsOutput(items) {
  return items
    .map((item) => {
      const mode = item.type === "dir" ? "drwxr-xr-x" : "-rw-r--r--";
      return `${mode} dev dev ${item.size.padStart(8)} ${item.modified.padStart(9)} ${item.name}`;
    })
    .join("\n");
}

function renderBreadcrumbs() {
  breadcrumbs.innerHTML = "";
  const parts = currentPath.split("/").filter(Boolean);
  let builtPath = "";
  parts.forEach((part, index) => {
    builtPath += `/${part}`;
    const button = document.createElement("button");
    button.className = "crumb";
    button.type = "button";
    button.textContent = index === 0 ? `/${part}` : part;
    button.addEventListener("click", () => openPath(builtPath));
    breadcrumbs.append(button);
  });
}

function renderFiles() {
  const items = tree[currentPath] || [];
  pathTitle.textContent = currentPath;
  itemCount.textContent = `${items.length} items`;
  fileRows.innerHTML = "";

  items.forEach((item) => {
    const row = document.createElement("button");
    row.type = "button";
    row.className = `file-row file-entry ${selected.has(item.name) ? "selected" : ""}`;
    row.innerHTML = `
      <span class="file-name">
        <span class="file-icon ${item.type === "dir" ? "folder" : ""}">${item.type === "dir" ? "DIR" : "DOC"}</span>
        <span class="file-label">${item.name}</span>
      </span>
      <span>${item.type}</span>
      <span>${item.size}</span>
      <span>${item.modified}</span>
    `;
    row.addEventListener("dblclick", () => {
      if (item.type === "dir") openPath(`${currentPath}/${item.name}`);
    });
    row.addEventListener("click", () => {
      if (selected.has(item.name)) selected.delete(item.name);
      else selected.add(item.name);
      renderFiles();
    });
    fileRows.append(row);
  });

  renderBreadcrumbs();
}

function openPath(path) {
  if (!tree[path]) return;
  focusWindow("filesWindow");
  currentPath = path;
  selected.clear();
  const items = tree[currentPath];
  command(`cd ${currentPath} && pwd && ls -lah`, `${currentPath}\n${linuxLsOutput(items)}`);
  renderFiles();
}

function copySelected() {
  focusWindow("transferWindow");
  const items = [...selected];
  if (!items.length) {
    command("echo 'No files selected'", "No files selected");
    return;
  }

  items.forEach((name) => {
    const item = document.createElement("article");
    item.className = "transfer-item";
    item.innerHTML = `
      <strong>${name}</strong>
      <span>${currentPath}/${name} &rarr; ${hostPath.value}</span>
      <div class="progress"><i></i></div>
    `;
    transferList.prepend(item);
    command(`scp -r dev@192.168.1.42:${currentPath}/${name} "${hostPath.value}"`, "copy complete");
  });

  selected.clear();
  renderFiles();
}

document.querySelector("#refreshButton").addEventListener("click", () => openPath(currentPath));
document.querySelector("#copySelectedButton").addEventListener("click", copySelected);
document.querySelector("#dropZone").addEventListener("click", copySelected);
document.querySelector("#clearLogButton").addEventListener("click", () => {
  logLines.length = 0;
  terminalLog.textContent = "";
});
document.querySelector("#upButton").addEventListener("click", () => {
  const parent = currentPath.split("/").slice(0, -1).join("/") || "/home/dev";
  openPath(tree[parent] ? parent : "/home/dev");
});

function focusWindow(id) {
  windows.forEach((windowEl) => windowEl.classList.toggle("focused", windowEl.id === id));
  launchers.forEach((button) => {
    button.classList.toggle("active", button.dataset.window === id);
  });
  taskApps.forEach((button) => {
    button.classList.toggle("active", button.dataset.window === id);
  });
  const focusedButton = document.querySelector(`[data-window="${id}"]`);
  if (focusedButton && activeApp) activeApp.textContent = focusedButton.title || focusedButton.textContent;
  document.querySelector(`#${id}`).scrollIntoView({ behavior: "smooth", block: "nearest" });
}

launchers.forEach((button) => {
  button.addEventListener("click", () => {
    focusWindow(button.dataset.window);
  });
});

taskApps.forEach((button) => {
  button.addEventListener("click", () => {
    focusWindow(button.dataset.window);
  });
});

document.querySelector("#connectionToggle").addEventListener("click", () => {
  document.querySelector(".rdp-strip").classList.toggle("collapsed");
});

windows.forEach((windowEl) => {
  windowEl.addEventListener("pointerdown", () => focusWindow(windowEl.id));
});

document.querySelectorAll(".desktop-icon").forEach((icon) => {
  icon.addEventListener("dblclick", () => openPath(icon.dataset.path));
  icon.addEventListener("click", () => focusWindow("filesWindow"));
});

openPath(currentPath);
